/*
 *	This file contains jsmn implementation
 */
#include <com/amazonaws/kinesis/video/common/jsmn.h>
