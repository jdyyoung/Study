---
name: Questions/Help
about: Describe this issue template's purpose here.
title: "[QUESTION]"
labels: question
assignees: ''

---

A one liner description about the use case and what you are trying to achieve

** Logging ** 
Add relevant SDK logging. IMPORTANT NOTE: Please make sure to NOT share AWS access credentials under any circumstance! Please make sure they are not in the logs.

** Any design considerations/constraints **
Explain in detail how you would like to integrate our SDK into your solution 

** If you would not like to open an issue to discuss your solution in open-platform, please email your question to kinesis-video-support@amazon.com **
