#ifndef __SERIAL_H
#define __SERIAL_H

#ifdef __cplusplus
extern "C" {
#endif

/*头文件*/

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <stdlib.h>


//#define DEBUG

#ifdef DEBUG
#define pr_debug(fmt, ...) printf(fmt, ##__VA_ARGS__)
#else
#define pr_debug(fmt, ...) 
#endif

#define SERIAL_DEVFILE_NAME "/dev/ttyS2"

struct serial_cmd {
    unsigned int bps;
    unsigned char databits;
    unsigned char stopbits;
    unsigned char parity;
    unsigned char reserved;
};

extern int serial_open(const char* devName);

extern void serial_close(int fd);

extern int serial_config(int fd, struct serial_cmd *serialctrl);

extern int serial_read(int fd, char *buf, int size);

extern int serial_write(int fd, char *buf, int size);

#ifdef __cplusplus
}
#endif

#endif
