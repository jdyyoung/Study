#ifndef __PTHREADTIMER_H
#define __PTHREADTIMER_H
#include <stdint.h>

typedef uint32_t mindex;
typedef void (*mptimer_work)(void *);


extern mindex ptimer_create( mptimer_work iwork, void * ipdata );
extern int ptimer_set( mindex iindex, mptimer_work iwork, void *ipdata );
extern int ptimer_start( mindex iindex, uint32_t iinterval );
extern int ptimer_stop( mindex iindex );

#endif

