#ifndef _UART_COMM_H_
#define _UART_COMM_H_

#ifdef __cplusplus
extern "C" {
#endif

void* uartInit(const char* devName);
int uartControl(void* s,unsigned char* argCmd, unsigned char* revMessage,int length);
int uartRelease(void* s);


#ifdef __cplusplus
}
#endif

#endif//_UART_COMM_H_
