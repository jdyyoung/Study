#include <pthread.h>
#include "yc_uart_comm.h"
#include "serial.h"
#include "pthreadtimer.h"
#include "ufo_init.h"

#define UART_BPS 4800//9600//9216//9984 //115200

#define true  1
#define false 0
#define REV_TIMEOUT_MS     100
#define REPEAT_SEND_COUNT 2
struct serial_t{
    int fd;
    struct serial_cmd serialctrl;
    pthread_t tid;
    char rbuf[4];
    char send_cmd[4];
    int revTimeoutFlag;
    int downTime;
    mindex index;
    pthread_mutex_t mutex;
};
static struct serial_t* serial = NULL;

static unsigned char checkSum(char* chk){
    unsigned char ret = 0;
    for(int i=0;i<3;i++){
        ret ^=chk[i];
    }
    return ~ret;
}

static void receive_cmd_reply_mcu(unsigned char cmd,unsigned char chks){
    serial->send_cmd[0] = 0xFA;
    serial->send_cmd[1] = cmd;
    serial->send_cmd[2] = chks;
    serial->send_cmd[3] = checkSum(serial->send_cmd);
    printf("receive commod and respone mcu data:");
    for(int i=0;i<4;i++){
        printf("0x%02x ",serial->send_cmd[i]);
    }
    printf("\n");
    if(-1 == serial_write(serial->fd,serial->send_cmd, sizeof(serial->send_cmd))){
            printf("%d:write cmd error!\n",__LINE__);
    }
}

static void uart_poweroff_cmd(){
    serial->send_cmd[0] = 0xFD;
    serial->send_cmd[1] = 0x02;
    serial->send_cmd[2] = 0x00;
    serial->send_cmd[3] = checkSum(serial->send_cmd);
    if(-1 == serial_write(serial->fd,serial->send_cmd, sizeof(serial->send_cmd))){
            printf("%d:write cmd error!\n",__LINE__);
    }
}
static void* play_poweroff_tip(void* parm){
    pthread_detach(pthread_self());
    pr("poweroff start ....\n");
    voice_add_play("/usr/share/wav/poweroff_tips.wav");
    voice_add_play("/usr/share/poweroff_tip.mp3");
    sleep(4);
    pr("power ..................off \n");
    uart_poweroff_cmd();
    return NULL;
}
static void power_off_handle(){
    pthread_t tid;
    ufo_lock_operation();
    pthread_create(&tid,NULL,play_poweroff_tip,NULL);
}

static void* uart_receive_cmd(void* s){
    int i,ret;
    unsigned char chks;
    int will_poweroff = 0;
    pthread_detach(pthread_self());
    while(1){
        pthread_mutex_lock(&serial->mutex);
        ret = serial_read(serial->fd, serial->rbuf, 4);
        if( ret >0){
            printf("receive data is:");
            for(i=0;i<4;i++){
                printf("0x%02x ",serial->rbuf[i]);
            }
            printf("\n");
            if(serial->rbuf[0] != 0xFD){
                pthread_mutex_unlock(&serial->mutex);
                continue;
            }
            if(serial->rbuf[3] == checkSum(serial->rbuf)){
                chks = 0x01;
            }
            else{
                chks = 0x00;
            }
            usleep(2000);
            receive_cmd_reply_mcu(serial->rbuf[1],chks);

            if(chks == 0x00){
                pthread_mutex_unlock(&serial->mutex);
                continue;
            }
            if(serial->rbuf[1] == 0x0B){
                //go_into_ufo_mode(_NONE_MODE);
                if(will_poweroff){
                    pthread_mutex_unlock(&serial->mutex);
                    continue;
                }
                pthread_mutex_unlock(&serial->mutex);
                usleep(1000);
                ufo_into_sleep_mode();
                continue;
            }
            else if(serial->rbuf[1] == 0x0D){
                //power_off notify
                will_poweroff = 1;
                power_off_handle();
            }
        }
        pthread_mutex_unlock(&serial->mutex);
        usleep(1000);
    }
    return NULL;
}

void* uartInit(const char* devName){
#if defined MZ_ZHL || defined YC_QX
    return NULL;
#endif
    serial = calloc(1,sizeof(struct serial_t));
    if(serial == NULL){
        printf("%d:calloc error!\n",__LINE__);
        return NULL;
    }
    
    pthread_mutex_init(&serial->mutex,NULL);
    serial->fd = serial_open(devName);
    if (serial->fd < 0) return NULL;

    serial->serialctrl.bps = UART_BPS;
    serial->serialctrl.stopbits = 1;
    serial->serialctrl.databits = 8;
    serial->serialctrl.parity = 'N';
    //serial->serialctrl.c_iflag &= ~(BRKINT | ICRNL | INPCK | ISTRIP | IXON);

    if (serial_config(serial->fd, &( serial->serialctrl )) == -1) return NULL;
    //建立线程不断接收消息
    pthread_create(&serial->tid,NULL,uart_receive_cmd,(void*)serial);
    serial->index = ptimer_create(NULL,NULL);
    return NULL;

}

static void receive_timeout_handle(){
    printf("receive timeout,will repeat send.....\n");
    serial->revTimeoutFlag = true;
}

static int uart_send_cmd(unsigned char* argCmd){
#if defined MZ_ZHL || defined YC_QX
    return 0;
#endif
    if(serial == NULL){
        pr("serial = NULL,no init,return!\n!");
        return -1;
    }
    for(int i=0;i<3;i++){
        serial->send_cmd[i] = argCmd[i];
    }
    //根据命令长度计算校验和
    serial->send_cmd[3] = checkSum((char*)argCmd);
    //发送数据处理
    int sendCnt = 0;
    pthread_mutex_lock(&serial->mutex);
    while(1){
        //发送命令
        //超时重发机制：100ms没收到回复，重发一次数据
        printf("send data:");
        for(int i=0;i<4;i++){
            printf("0x%02x ",serial->send_cmd[i]);
         }
        printf("\n");
        if(-1 == serial_write(serial->fd,serial->send_cmd, sizeof(serial->send_cmd))){
            printf("%d:write cmd error!\n",__LINE__);
            break;
        }
        serial->revTimeoutFlag = false;
        //开启定时
        serial->downTime = REV_TIMEOUT_MS;
        ptimer_stop(serial->index);
        ptimer_set(serial->index,receive_timeout_handle,NULL);
        ptimer_start(serial->index,serial->downTime);
        //不断接收，接收到了判断
        while(!serial->revTimeoutFlag){
            if (serial_read(serial->fd, serial->rbuf, 4) > 0){
                ptimer_stop(serial->index);
                for( int i=0;i<4;i++){
                    printf("0x%02x ",serial->rbuf[i]);
                }
                printf("\n");
                pthread_mutex_unlock(&serial->mutex);
                if (serial->rbuf[0] == 0xfa && serial->rbuf[1] == 0x0c &&
                    serial->rbuf[2] == 0x01 && serial->rbuf[3] == 0x08)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
                
            }
        }
        usleep(5000);
        sendCnt++;
        if(sendCnt == REPEAT_SEND_COUNT){
            break;
        }
    }
    pthread_mutex_unlock(&serial->mutex);
    return 0;
}

static  unsigned char uart_cmd[9][3] = {
        {0xFD,0x01,0x01},//SP_EN
        {0xFD,0x01,0x00},//SP_DIS
        {0xFD,0x02,0x00},//POWER_CTL
        {0xFD,0x03,0x00},//LED_PWM灯常亮
        {0xFD,0x04,0x00},//LED_PWM灯常灭
        {0xFD,0x09,0x01},//LED_PWM_1灯常亮
        {0xFD,0x09,0x00},//LED_PWM_1灯常灭
        {0xFD,0x0E,0x00},//LED_PWM LED_PWM_1灯常灭
        {0xFD,0x0E,0x01},//LED_PWM LED_PWM_1灯常亮
        // {0xFD,0x03,0x0A},//PWM Breath 10*100ms
        // {0xFD,0x04,0x0A},//PWM flash 10*100ms
        // {0xFD,0x09,0x0A},//PWM_1 Breath 10*100ms
        // {0xFD,0x0A,0x0A},//PWM_1 flash 10*100ms
        // {0xFD,0x0B,0x00},//暂停/播放
 };

void uart_spkeak_enable()
{
    uart_send_cmd(uart_cmd[0]);
}
void uart_spkeak_disable()
{
    uart_send_cmd(uart_cmd[1]);
}
void uart_poweroff()
{
    uart_send_cmd(uart_cmd[2]);
}
void uart_led_on(){
    uart_send_cmd(uart_cmd[3]);
}
void uart_led_off(){
    uart_send_cmd(uart_cmd[4]);
}
void uart_led_1_on(){
    uart_send_cmd(uart_cmd[5]);
}
void uart_led_1_off(){
    uart_send_cmd(uart_cmd[6]);
}
void uart_led_breath(unsigned char time_x10_ms)
{
    if(!time_x10_ms){
        pr("time_x10_ms  == 0,return\n");
        return;
    }
    unsigned char cmd[3] = {0xFD,0x03,0x0A};
    cmd[2] = time_x10_ms;
    uart_send_cmd(cmd);
}
void uart_led_flash(unsigned char time_x10_ms)
{
    if(!time_x10_ms){
        pr("time_x10_ms  == 0,return\n");
        return;
    }
    unsigned char cmd[3] = {0xFD,0x04,0x0A};
    cmd[2] = time_x10_ms;
    uart_send_cmd(cmd);
}

void uart_led_1_flash(unsigned char time_x10_ms)
{
    if(!time_x10_ms){
        pr("time_x10_ms  == 0,return\n");
        return;
    }
    unsigned char cmd[3] = {0xFD,0x0A,0x0A};
    cmd[2] = time_x10_ms;
    uart_send_cmd(cmd);
}

void uart_leds_off()
{
    uart_send_cmd(uart_cmd[7]);
}
void uart_leds_on()
{
    uart_send_cmd(uart_cmd[8]);
}
void uart_leds_flash(unsigned char time_x10_ms)
{
    if(!time_x10_ms){
        pr("time_x10_ms  == 0,return\n");
        return;
    }
    unsigned char cmd[3] = {0xFD,0x0F,0x0A};
    cmd[2] = time_x10_ms;
    uart_send_cmd(cmd);
}
void uart_leds_flash_replace(unsigned char time_x10_ms)
{
    if(!time_x10_ms){
        pr("time_x10_ms  == 0,return\n");
        return;
    }
    unsigned char cmd[3] = {0xFD,0x10,0x0A};
    cmd[2] = time_x10_ms;
    uart_send_cmd(cmd);
}

int uart_check_usb_insert()
{
    unsigned char cmd[3] = {0xFD,0x0c,0x00};
    return uart_send_cmd(cmd);
}


int uartRelease(){
#if defined MZ_ZHL || defined YC_QX
    return 0;
#endif
    if(serial == NULL){
        pr("serial = NULL,no init,return!\n!");
        return -1;
    }
    pthread_mutex_destroy(&serial->mutex);
    serial_close(serial->fd);
    free(serial);
    return 0;
}
