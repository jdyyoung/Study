#include <stdio.h>
#include<getopt.h>
#include <unistd.h>

#include "uart_comm.h"

#define SERIAL_DEVFILE_NAME "/dev/ttySAK1"

static  unsigned char cmd[11][3] = {
        {0xFD,0x01,0x01},//SP_EN
        {0xFD,0x01,0x00},//SP_DIS
        {0xFD,0x02,0x00},//POWER_CTL
        {0xFD,0x03,0x00},//LED_PWM灯常灭
        {0xFD,0x04,0x00},//LED_PWM灯常亮
        {0xFD,0x09,0x01},//LED_PWM_1灯常亮
        {0xFD,0x09,0x00},//LED_PWM_1灯常灭
        {0xFD,0x03,0x0A},//PWM Breath 10*100ms
        {0xFD,0x04,0x0A},//PWM flash 10*100ms
        {0xFD,0x0A,0x0A},//PWM_1 flash 10*100ms
        {0xFD,0x0C,0x00},//查询是否有USB插入
 };

unsigned char* testArr = cmd[0];
//unsigned char* revMessage = cmd[1];
//unsigned char cmd[2] = {0x62,0x01};

static void ledCtrlCommon_test(unsigned char* parm){
// static void ledCtrlCommon_test(){
    //unsigned char parm[3] = {0xFD,0x03,0x0A};
    //unsigned char parm[3] = {0xFD,0x02,0x00};
    // unsigned char parm[3] = {0xFD,0x01,0x01};
    void* s= uartInit(SERIAL_DEVFILE_NAME);
    uart_send_cmd(s,parm);

    // while(1){
    //     usleep(1000);
    // };
    usleep(250000);
    uartRelease(s); 
}

static void usage(int argc, char *argv[])
{
    fprintf(stderr, "Usage: %s [-abcdefgijklh:]\n", argv[0]);
    fprintf(stderr, "    -a: SP_EN\n");
    fprintf(stderr, "    -b: SP_DIS\n");
    fprintf(stderr, "    -c: POWER_CTL\n");
    fprintf(stderr, "    -d: LED_PWM ON \n");
    fprintf(stderr, "    -e: LED_PWM OFF\n");
    fprintf(stderr, "    -f: LED_PWM_1 ON \n");
    fprintf(stderr, "    -g: LED_PWM_1 OFF \n");
    fprintf(stderr, "    -i: LED_PWM BREATH\n");
    fprintf(stderr, "    -j: LED_PWM FLASH\n");
    fprintf(stderr, "    -k: LED_PWM_1 FLASH\n");
    fprintf(stderr, "    -l: INQUIRE USB INSERT \n");
}

int main(int argc, char *argv[])
{
    int c;
    int mode = 0;
    printf("test start...\n");

    opterr = 0;
    do {
        c = getopt(argc, argv, "abcdefgijklh");
        if (c == EOF)
            break;
        switch (c) {
            case 'a':
                testArr = cmd[0];
                break;
            case 'b':
                testArr = cmd[1];
                break;
            case 'c':
                testArr = cmd[2];
                break;
            case 'd':
                testArr = cmd[3];
                break;
            case 'e':
                testArr = cmd[4];
                break;
            case 'f':
                testArr = cmd[5];
                break;
            case 'g':
                testArr = cmd[6];
                break;
            case 'i':
                testArr = cmd[7];
                break;
            case 'j':
                testArr = cmd[8];
                break;
            case 'k':
                testArr = cmd[9];
                break;
            case 'l':
                testArr = cmd[10];
                break;
            case '?':
                fprintf(stderr, "%s: invalid option -%c\n",
                        argv[0], optopt);
            case 'h':
                usage(argc, argv);
                return -1;
        }
    }while(1);

    ledCtrlCommon_test(testArr);
    //ledCtrlCommon_test();

    return 0;
}
