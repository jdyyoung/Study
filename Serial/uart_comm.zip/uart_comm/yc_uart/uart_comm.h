#ifndef _UART_COMM_H_
#define _UART_COMM_H_

#ifdef __cplusplus
extern "C" {
#endif

void* uartInit(const char* devName);
int uart_send_cmd(void* s,unsigned char* argCmd);
int uartRelease(void* s);


#ifdef __cplusplus
}
#endif

#endif//_UART_COMM_H_
