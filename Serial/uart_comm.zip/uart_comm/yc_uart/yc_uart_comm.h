#ifndef _UART_COMM_H_
#define _UART_COMM_H_

#ifdef __cplusplus
extern "C" {
#endif

void* uartInit(const char* devName);
//int uart_send_cmd(void* s,unsigned char* argCmd);
int uartRelease();
void uart_spkeak_enable();
void uart_spkeak_disable();
void uart_poweroff();
void uart_led_off();
void uart_led_on();
void uart_led_1_off();
void uart_led_1_on();
void uart_led_breath(unsigned char time_x10_ms);
void uart_led_flash(unsigned char time_x10_ms);
void uart_led_1_flash(unsigned char time_x10_ms);
void uart_leds_off();
void uart_leds_on();
void uart_leds_flash(unsigned char time_x10_ms);
void uart_leds_flash_replace(unsigned char time_x10_ms);
int uart_check_usb_insert();
#ifdef YC_ALD
void  aladdin_ctrl_led(unsigned char on_off);
void  aladdin_ctrl_led_brightness(unsigned char bright_dark, unsigned char strength);
#endif
#ifdef __cplusplus
}
#endif

#endif//_UART_COMM_H_
