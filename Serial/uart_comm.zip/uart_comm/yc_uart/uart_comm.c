#include <pthread.h>
#include "uart_comm.h"
#include "serial.h"
#include "pthreadtimer.h"


#define UART_BPS 115200//4800//9600//9216//9984 //115200
#define true  1
#define false 0
#define REV_TIMEOUT_MS     100
#define REPEAT_SEND_COUNT 2
struct serial_t{
    int fd;
    struct serial_cmd serialctrl;
    pthread_t tid;
    char rbuf[4];
    char send_cmd[4];
    int revTimeoutFlag;
    int downTime;
    mindex index;
    pthread_mutex_t mutex;
};

static unsigned char checkSum(char* chk){
    unsigned char ret = 0;
    for(int i=0;i<3;i++){
        ret ^=chk[i];
    }
    return ~ret;
}

static void receive_cmd_reply_mcu(void* s,unsigned char cmd,unsigned char chks){
    struct serial_t* serial =(struct serial_t*)s;
    serial->send_cmd[0] = 0xFA;
    serial->send_cmd[1] = cmd;
    serial->send_cmd[2] = chks;
    serial->send_cmd[3] = checkSum(serial->send_cmd);
    if(-1 == serial_write(serial->fd,serial->send_cmd, sizeof(serial->send_cmd))){
            printf("%d:write cmd error!\n",__LINE__);
    }
}
static void* uart_receive_cmd(void* s){
    int i,ret;
    unsigned char chks;
    struct serial_t* serial =(struct serial_t*)s;
    pthread_detach(pthread_self());
    while(1){
        pthread_mutex_lock(&serial->mutex);
        ret = serial_read(serial->fd, serial->rbuf, 4);
        if( ret >0){
            printf("receive data is:");
            for(i=0;i<4;i++){
                printf("0x%02x ",serial->rbuf[i]);
            }
            printf("\n");
            if(serial->rbuf[3] == checkSum(serial->rbuf)){
                chks = 0x01;
            }
            else{
                chks = 0x00;
            }
            receive_cmd_reply_mcu(serial,serial->rbuf[1],chks);
        }
        pthread_mutex_unlock(&serial->mutex);
        usleep(1000);
    }
    return NULL;
}
void* uartInit(const char* devName){
    struct serial_t*  serial = calloc(1,sizeof(struct serial_t));
    if(serial == NULL){
        printf("%d:calloc error!\n",__LINE__);
        return NULL;
    }
    
    pthread_mutex_init(&serial->mutex,NULL);
    serial->fd = serial_open(devName);
    if (serial->fd < 0) return NULL;

    serial->serialctrl.bps = UART_BPS;
    serial->serialctrl.stopbits = 1;
    serial->serialctrl.databits = 8;
    serial->serialctrl.parity = 'N';

    if (serial_config(serial->fd, &( serial->serialctrl )) == -1) return NULL;
    //建立线程不断接收消息
    pthread_create(&serial->tid,NULL,uart_receive_cmd,(void*)serial);
    serial->index = ptimer_create(NULL,NULL);
    return (void*)serial;

}

static void receive_timeout_handle(void* s){
    struct serial_t* serial =(struct serial_t*)s;
    printf("receive timeout,will repeat send.....\n");
    serial->revTimeoutFlag = true;
}

int uart_send_cmd(void* s,unsigned char* argCmd){
    if(s == NULL || argCmd == NULL){
        printf("%s:void* s = NULL\n!",__func__);
        return -1;
    }
    struct serial_t* serial =(struct serial_t*)s;
    for(int i=0;i<3;i++){
        serial->send_cmd[i] = argCmd[i];
    }
    //根据命令长度计算校验和
    serial->send_cmd[3] = checkSum((char*)argCmd);
    //发送数据处理

    int sendCnt = 0;
    pthread_mutex_lock(&serial->mutex);
    while(1){
        //发送命令
        //超时重发机制：100ms,没收到回复，重发一次数据
        printf("send data is:");
        for(int i=0;i<4;i++){
            printf("0x%02x ",serial->send_cmd[i]);
        }
        printf("\n");
        if(-1 == serial_write(serial->fd,serial->send_cmd, sizeof(serial->send_cmd))){
            printf("%d:write cmd error!\n",__LINE__);
            break;
        }
        serial->revTimeoutFlag = false;
        //开启定时
        serial->downTime = REV_TIMEOUT_MS;
        ptimer_stop(serial->index);
        ptimer_set(serial->index,receive_timeout_handle,serial);
        ptimer_start(serial->index,serial->downTime);
        //不断接收，接收到了判断
        while(!serial->revTimeoutFlag){
            if (serial_read(serial->fd, serial->rbuf, 4) > 0){
                ptimer_stop(serial->index);
                printf("receive data is:");
                for( int i=0;i<4;i++){
                    printf("0x%02x ",serial->rbuf[i]);
                }
                printf("\n");
                if(serial->rbuf[0] == 0xfa && serial->rbuf[3] == checkSum(serial->rbuf)){
                    printf("receive data is OKOK OKOK \n");
                }
                else{
                    printf("receive data is ONON ONON \n");
                }

                pthread_mutex_unlock(&serial->mutex);
                return 0;
            }
        }
        usleep(5000);
        sendCnt++;
        if(sendCnt == REPEAT_SEND_COUNT){
            break;
        }
    }
    pthread_mutex_unlock(&serial->mutex);
    return 0;
}

int uartRelease(void* s){
    if(s == NULL){
        printf("%s:void* s = NULL\n!",__func__);
        return -1;
    }
    struct serial_t* serial =(struct serial_t*)s;
    pthread_mutex_destroy(&serial->mutex);
    serial_close(serial->fd);
    free(s);
    return 0;
}

