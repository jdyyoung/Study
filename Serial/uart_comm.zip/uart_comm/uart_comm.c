#include "uart_comm.h"
#include "serial.h"
#include "pthreadtimer.h"

#define true  1
#define false 0
#define TIME_50MS        50
#define REPEAT_SEND_COUNT 3
struct serial_t{
    int fd;
    struct serial_cmd serialctrl;
   // pthread_t serial_read_threadID;
    unsigned char rbuf[8];
    unsigned char send_cmd[512];
    int revTimeoutFlag;
    int downTime;
    mindex index;
};

void* uartInit(const char* devName){
    struct serial_t*  serial = calloc(1,sizeof(struct serial_t));
    if(serial == NULL){
        printf("%d:calloc error!\n",__LINE__);
        return NULL;
    }

    serial->fd = serial_open(devName);
    if (serial->fd < 0) return NULL;

    serial->serialctrl.bps = 115200;
    serial->serialctrl.stopbits = 1;
    serial->serialctrl.databits = 8;
    serial->serialctrl.parity = 'N';

    if (serial_config(serial->fd, &( serial->serialctrl )) == -1) return NULL;
    serial->index = ptimer_create(NULL,NULL);

    return (void*)serial;

}

static unsigned char checkSum(unsigned char* chk,int  cnt){
    unsigned char ret = 0;
    for(int i=0;i<cnt;i++){
        ret +=chk[i];
    }
    ret = ~ret;
    if(ret != 0xFF){
        ret += 1;
    }
    return ret;
}
static void receive_timeout_handle(void* s){
    struct serial_t* serial =(struct serial_t*)s;
    serial->revTimeoutFlag = true;
}

int uartControl(void* s,unsigned char* argCmd, unsigned char* revMessage,int length){
    if(s == NULL || argCmd == NULL){
        printf("%s:void* s = NULL\n!",__func__);
        return -1;
    }
    struct serial_t* serial =(struct serial_t*)s;
    serial->send_cmd[0] = 0xAA;
    //接收到命令和参数后，统计命令和参数的长度，填充两个字节的长度
    serial->send_cmd[1] =(unsigned char) length >> 8;
    serial->send_cmd[2] = (unsigned char) length & 0x000000ff;
    for(int i=0;i<length;i++){
        serial->send_cmd[3+i] = argCmd[i];
    }
    //根据命令长度计算校验和
    serial->send_cmd[length+3] = checkSum(&(serial->send_cmd[1]),length+2);
    //发送数据处理
    int sendCnt = 0;
    int sendFlag = true;
    while(sendFlag){
        //发送命令
        for(int j=0;j< length+4;j++){
            printf("0x%02X ",serial->send_cmd[j]);
            if(write(serial->fd,(char*)&serial->send_cmd[j],1) != 1){
                printf("%s:write cmd error!\n",__LINE__);
                return -1;
            }
            usleep(800);
        }
        printf("\n");
        serial->revTimeoutFlag = false;
        //开启定时
        serial->downTime = TIME_50MS;
        ptimer_stop(serial->index);
        ptimer_set(serial->index,receive_timeout_handle,serial);
        ptimer_start(serial->index,serial->downTime);
        //不断接收，接收到了判断
        while(!serial->revTimeoutFlag){
            if(serial->send_cmd[3] == 0x63){
                usleep(2000);
            }
            if (read(serial->fd, serial->rbuf, 8) > 0){
                ptimer_stop(serial->index);
                for( int i=0;i<8;i++){
                    printf("0x%02x ",serial->rbuf[i]);
                }
                printf("\n");
                if(serial->send_cmd[3] == 0x68 || serial->send_cmd[3] == 0x69 ){
                    if(serial->rbuf[7] == checkSum(&(serial->rbuf[1]),6)){
                        if(serial->rbuf[3] == 0x5A ){
                            printf("Get E003 MCU version is:%d.%d.%d\n",serial->rbuf[4],serial->rbuf[5],serial->rbuf[6]);
                           // for(int i=0;i<3;i++){
                           //   revMessage[i] = serial->rbuf[4+i];
                          //}
                            return 1;
                        }
                        else if(serial->rbuf[3] == 0x5B){
                            printf("Get E003 MCU CCT=0x%02x%02x,intensity=%d\n",serial->rbuf[4],serial->rbuf[5],serial->rbuf[6]);
                            for(int i=0;i<3;i++){
                                revMessage[i] = serial->rbuf[4+i];
                            }
                            return 1;
                        }
                    }
                }
                else{
                    if(serial->rbuf[5] == checkSum(&(serial->rbuf[1]),4)){
                        if(serial->rbuf[4] == serial->send_cmd[3] || serial->rbuf[3] == 0x5C){
                            //ack ok!!!
                            revMessage[0] = serial->rbuf[4];
                            return 1;
                        }
                    }
                }
                break;
                //memset(&serial->rbuf,0,sizeof(serial->rbuf));
            }
        }

        if(sendFlag){
            sendCnt++;
            if(sendCnt == REPEAT_SEND_COUNT){
                //break;
                return 0;
            }
        }
    }
}
int uartRelease(void* s){
    if(s == NULL){
        printf("%s:void* s = NULL\n!",__func__);
        return -1;
    }
    struct serial_t* serial =(struct serial_t*)s;
    serial_close(serial->fd);
    free(s);
    return 0;
}

