#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/time.h>
#include <unistd.h>

//#include "../utils.h"
#include "pthreadtimer.h"

// #include "../mozart/tests/Debug.h"

// =============================================================================
typedef struct{
    mindex          aindex;
    mptimer_work    awork;
    void           *apdata;
    uint64_t        aetime; // trigger time
    void           *anext;
}muser;

typedef struct{
    mindex          aindex;
    pthread_t       athrdid;
    pthread_mutex_t amutex;
    pthread_cond_t  acond;
    pthread_mutex_t acondmutex;
    muser           *auserlist;
}mpthreadtimer;

// =============================================================================
static mpthreadtimer *sf_create_pthread_timer( void );
static void *sf_pthread_timer_loop( void *pdata );

// =============================================================================
static mpthreadtimer *sp_timer = NULL;

// =============================================================================
mindex ptimer_create( mptimer_work iwork, void *ipdata ){
    muser      *tp_user;
    mindex      tv_index;

    if( sp_timer == NULL )
        sp_timer = sf_create_pthread_timer();
    tv_index = sp_timer->aindex++;
    if( sp_timer->aindex > 0xFFFE )
        printf( "To many users!" );

    if( (tp_user = malloc( sizeof(muser) ) ) == NULL )
        printf( "FRQ.user_mem!" );
    memset( tp_user, 0x00, sizeof(muser) );
    tp_user->awork = iwork;
    tp_user->apdata = ipdata;
    tp_user->aindex = tv_index;
    tp_user->anext = NULL;

    pthread_mutex_lock( &(sp_timer->amutex) );
    if( sp_timer->auserlist == NULL ){
        sp_timer->auserlist = tp_user;
    }else{
        muser      *tp_node;
        tp_node = sp_timer->auserlist;
        while( tp_node->anext != NULL )
            tp_node = tp_node->anext;
        tp_node->anext = tp_user;
    }
    pthread_mutex_unlock( &(sp_timer->amutex) );

    return tv_index;
}

int ptimer_set( mindex iindex, mptimer_work iwork, void *ipdata ){
    muser          *tp_user = NULL;
    int             tv_ret = 0;

    if( sp_timer == NULL ) return -1;
    pthread_mutex_lock( &(sp_timer->amutex) );
    if( sp_timer->auserlist != NULL ){
        muser      *tp_node;
        tp_node = sp_timer->auserlist;
        while( tp_node != NULL ){
            if( tp_node->aindex == iindex ){
                tp_user = tp_node;
                break;
            }
            tp_node = tp_node->anext;
        }
        if( tp_user != NULL ){
            tp_user->awork = iwork;
            tp_user->apdata = ipdata;
        }else{ tv_ret = -1; }
    }else{ tv_ret = -1; }
    pthread_mutex_unlock( &(sp_timer->amutex) );
    return tv_ret;

}

int ptimer_start( mindex iindex, uint32_t iinterval ){
    muser          *tp_user = NULL;
    struct timeval  tv_now;
    int             tv_ret = 0;

    if( sp_timer == NULL ) return -1;
    tv_ret = gettimeofday( &tv_now, NULL );
    pthread_mutex_lock( &(sp_timer->amutex) );
    if( sp_timer->auserlist != NULL ){
        muser      *tp_node;
        tp_node = sp_timer->auserlist;
        while( tp_node != NULL ){
            if( tp_node->aindex == iindex ){
                tp_user = tp_node;
                break;
            }
            tp_node = tp_node->anext;
        }
        if( tp_user != NULL ){
            tp_user->aetime = (uint64_t)(tv_now.tv_sec*1000 +\
                              tv_now.tv_usec/1000) + (uint64_t)iinterval;
        }else{ tv_ret = -1; }
    }else{ tv_ret = -1; }
    pthread_cond_broadcast( &sp_timer->acond );
    pthread_mutex_unlock( &(sp_timer->amutex) );
    return tv_ret;
}

int ptimer_stop( mindex iindex ){
    muser          *tp_user = NULL;
    int             tv_ret = 0;

    if( sp_timer == NULL ) return -1;
    pthread_mutex_lock( &(sp_timer->amutex) );
    if( sp_timer->auserlist != NULL ){
        muser      *tp_node;
        tp_node = sp_timer->auserlist;
        while( tp_node != NULL ){
            if( tp_node->aindex == iindex ){
                tp_user = tp_node;
                break;
            }
            tp_node = tp_node->anext;
        }
        if( tp_user != NULL ){
            tp_user->aetime = 0;
        }else{ tv_ret = -1; }
    }else{ tv_ret = -1; }
    pthread_mutex_unlock( &(sp_timer->amutex) );
    return tv_ret;
}

static mpthreadtimer *sf_create_pthread_timer( void ){
    mpthreadtimer *tp_timer;
    if( ( tp_timer = malloc( sizeof(mpthreadtimer) ) ) == NULL )
        printf( "FRQ.mem!" );
    memset( tp_timer, 0x00, sizeof(mpthreadtimer) );

    pthread_mutex_init( &tp_timer->amutex, NULL );
    pthread_cond_init( &tp_timer->acond, NULL );
    pthread_mutex_init( &tp_timer->acondmutex, NULL );
    if( pthread_create( &tp_timer->athrdid, NULL, sf_pthread_timer_loop, tp_timer ) )
        printf( "FC.pthread!" );
    return tp_timer;
}

static void *sf_pthread_timer_loop( void *pdata ){
    mpthreadtimer      *tp_timer = pdata;
    int                 tv_needsleep = 1;
    struct timeval      tv_now;
    uint64_t            tv_now_ms;
    muser              *tp_user;

    if( pdata == NULL ) return NULL;

    pthread_detach( pthread_self() );
    while(1){
        while(1){
            gettimeofday( &tv_now, NULL );
            tv_now_ms = tv_now.tv_sec*1000+tv_now.tv_usec/1000;
            tv_needsleep = 1;
            pthread_mutex_lock( &tp_timer->amutex );
            tp_user = tp_timer->auserlist;
            while( tp_user ){
                if( tp_user->aetime != 0 ){
                    if( tv_now_ms >= tp_user->aetime ){
                        if( tp_user->awork )
                            tp_user->awork( tp_user->apdata );
                        tp_user->aetime = 0;
                    }else{
                        tv_needsleep = 0;
                    }
                }
                tp_user = tp_user->anext;
            }
            pthread_mutex_unlock( &tp_timer->amutex );
            if( tv_needsleep ) break;
            else usleep( 10000 );
        }
        pthread_cond_wait( &tp_timer->acond, &tp_timer->acondmutex );
    }
    pthread_exit(NULL);
}

