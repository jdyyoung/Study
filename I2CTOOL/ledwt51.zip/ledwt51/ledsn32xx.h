#ifndef _LEDSN32XX_H_
#define _LEDSN32XX_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "i2cWrite.h"
#include <pthread.h>
#include <unistd.h>

enum led_mode{
	/*function mode*/
	MODE_DEFAULT=0,
	MODE_LISTENING,
	MODE_THINKING,
	MODE_SPEAKING,

	MODE_RED,
	MODE_GREEN,
	MODE_BLUE,
	MODE_CYAN,
	MODE_CYAN_BLUE,
	MODE_BLUE_CYAN,
	MODE_BREATH_R,
	MODE_BREATH_G,
	MODE_BREATH_B,
	MODE_BREATH_RED_CYAN,
};

/*
 * 0 : SN3236  1: SN3218
 * return value : -1 fail  0 :sucess
 */
void* ledSn32xxInit(int board);
int ledSn32xxShow(void* l,int mode);
int ledSn32xxRelease(void* l);

#ifdef __cplusplus
}
#endif

#endif//_LEDSN32XX_H_
