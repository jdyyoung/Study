/*
 * This file is part of ledring.
 * Copyright (c) amlogic 2017
 * All rights reserved.
 * author:renjun.xu@amlogic.com
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software.
 *
 */
//#include <unistd.h>
#include "ledsn32xx.h"

#define TRUE  0
#define FALSE -1

//#define DEBUG

#ifdef DEBUG
	#define Debug(fmt, ...)		printf("L(%d): "fmt"\n",__LINE__,##__VA_ARGS__)
#else
	#define Debug(fmt, ...)
#endif

// G->R->B 开发板
// B->R->G

//unsigned char led_control[36] = {0};
//unsigned char led_pwm[36] = {0};

#if 1
unsigned char led_recoup[32] = {0,1,2,4,6,10,13,18,22,28,33,39,46,53,61,69,78,86,96,106,
	                            116,126,138,149,161,173,186,199,212,226,240,255};
#else
unsigned char led_recoup[64] = {0,1,2,3,4,5,6,7,8,10,12,14,16,18,20,22,24,26,29,32,35,38,41,44,47,50,53,57,61,65,69,73,
								77,81,85,89,94,99,104,109,114,119,124,129,134,140,146,152,158,164,170,176,182,188,195,202,209,216,223,230,237,244,251,255};
#endif 

enum _COLOUR{
	BLUE=0,
	RED,
	GREEN,
};

enum _EFFECT{
	MODE1=0,
	MODE2,
	MODE3,
	MODE4,
	MODE5,
};

enum _COUNT{
	CNT1=3,
	CNT2=6,
	CNT3=9,
};

struct leds_t{
	pthread_t thread;
	int i2cNum;
	int working;
	int breakin;
	int mode;
	int board;
	int slave_addr;
	int max_leds;
	int def_flag;
	unsigned char led_control[36];
	unsigned char led_pwm[36];
	unsigned char led_pwm_one[6];
	enum _COLOUR colour;
	enum _EFFECT effect;
	enum _COUNT  count;
};

static int LEDDriver_Init(struct leds_t *leds){
	int ret = 0;
	unsigned char i = 0;
	unsigned char reg[] = {0x00,0x00};
	unsigned char regValue[] = {0x00,0x01};
	if(!leds->board){
		// CONFIG_SN3236
		reg[0] = 0x4f;
		leds->slave_addr = 0x3c;
		leds->max_leds = 36;
	}else{
		// CONFIG_SN3218
		reg[0] = 0x17;
		leds->slave_addr = 0x54;
		leds->max_leds = 6;
	}
	for(int i=0; i<sizeof(reg)/sizeof(char); i++){
		ret = i2cWriteNbyte(&leds->i2cNum,leds->slave_addr,reg[i],1,&regValue[i]);
		if(ret < 0){
			Debug("## i2cWrite fail\n");
			return -1;
		}
	}
	return 0;
}

static int LEDDriver_Enable(struct leds_t *leds){
	int ret = 0;
	Debug("LEDDriver_Enable board = %d",leds->board);
	if(!leds->board){
		unsigned char reg[] = {0x26,0x01,0x25};
		ret = i2cWriteNbyte(&leds->i2cNum,leds->slave_addr,reg[0],36,leds->led_control);
		if(ret < 0){
			Debug("## i2cWrite fail\n");
			return -1;
		}
		ret = i2cWriteNbyte(&leds->i2cNum,leds->slave_addr,reg[1],36,leds->led_pwm);
		if(ret < 0){ Debug("## i2cWrite fail\n");
			return -1;
		}
		ret = i2cWriteNbyte(&leds->i2cNum,leds->slave_addr,reg[2],1,&reg[2]);
		if(ret < 0){
			Debug("## i2cWrite fail\n");
			return -1;
		}
	}else{
		unsigned char reg[] = {0x13,0x14,0x15,0x07,0x08,0x09,0x16};
		int i = 0;

		Debug("led->control_0 = 0x%x",leds->led_control[0]);

		// need again init 
		LEDDriver_Init(leds);

		ret = i2cWriteNbyte(&leds->i2cNum,leds->slave_addr,reg[1],1,&leds->led_control[0]);
		if(ret < 0){
			Debug("## i2cWrite fail\n");
			return -1;
		}
		ret = i2cWriteNbyte(&leds->i2cNum,leds->slave_addr,reg[3],6,leds->led_pwm_one);
		if(ret < 0){
			Debug("## i2cWrite fail\n");
			return -1;
		}

		ret = i2cWriteNbyte(&leds->i2cNum,leds->slave_addr,reg[6],1,&reg[0]);
		if(ret < 0){
			Debug("## i2cWrite fail\n");
			return -1;
		}
	}
	return 0;
}

int LEDDriver_GlobalOff(struct leds_t *leds){
	int ret = 0;
	if(!leds->def_flag){
		if(!leds->board){
			for(int i=0;i<leds->max_leds;i++){
				leds->led_control[i] = 0x00;
				leds->led_pwm[i] = 0x0;
			}
		}else{
			for(int i=0;i<leds->max_leds;i++){
				leds->led_control[0] = 0x00;
				leds->led_pwm_one[i] = 0x0;
			}
		}
		ret = LEDDriver_Enable(leds);
		if(ret < 0){
			Debug("## i2cWrite fail\n");
			return -1;
		}
		leds->def_flag = 1;
	}
}

int sn3218_led_cal(unsigned char pwm,struct leds_t *leds){
	switch(leds->effect){
		case MODE1:
			for(int i=0;i<leds->max_leds;i++){
				leds->led_control[0] = 0x02;
				leds->led_pwm_one[i] = led_recoup[pwm];
			}
			break;
		case MODE2:
			for(int i=0;i<leds->max_leds;i++){
				leds->led_control[0] = 0x04;
				leds->led_pwm_one[i] = led_recoup[pwm];
			}
			break;
		case MODE3:
			for(int i=0;i<leds->max_leds;i++){
				leds->led_control[0] = 0x08;
				leds->led_pwm_one[i] = led_recoup[pwm];
			}
			break;
		case MODE4:
			for(int i=0;i<leds->max_leds;i++){
				leds->led_control[0] = 0x0a;
				leds->led_pwm_one[i] = led_recoup[pwm];
			}
			break;
		default:
			break;
		}
	return 0;
}


int sn3236_led_cal(unsigned char pwm,struct leds_t *leds){
	switch(leds->effect){
		case MODE1:
			for(int i=0;i<leds->max_leds;i++){
				if(leds->colour == i%leds->count){
					leds->led_control[i] = 0x01;
					leds->led_pwm[i] = led_recoup[pwm];
				}else{
					leds->led_control[i] = 0x0;
				}
			}
			break;
		case MODE2:
			for(int i=0;i<leds->max_leds;i++){
				if(leds->colour != i%leds->count){
					leds->led_control[i] = 0x01;
					leds->led_pwm[i] = led_recoup[pwm];
				}else{
					leds->led_control[i] = 0x0;
				}
			}
		case MODE3: 
			for(int i=0;i<leds->max_leds;i++){
				if((leds->colour == i%leds->count)||(2 == i%6)){
					leds->led_control[i] = 0x01;
					leds->led_pwm[i] = led_recoup[pwm];
				}else{
					leds->led_control[i] = 0x0;
				}
			}
			break;
		case MODE4: 
			for(int i=0;i<leds->max_leds;i++){
				if((leds->colour == i%leds->count)||((1 == i%2)&&(2 == i%3))){
					leds->led_control[i] = 0x01;
					leds->led_pwm[i] = led_recoup[pwm];
				}else{
					leds->led_control[i] = 0x0;
				}
			}
			break;
		case MODE5:
			for(int i=0;i<leds->max_leds;i++){
				if(leds->colour == i%leds->count){
					leds->led_control[i] = 0x00;
				}else{
					leds->led_control[i] = 0x01;
					leds->led_pwm[i] = led_recoup[pwm];
				}
			}
			break;
		default:
			break;
	}
	return 0;
}
/*
 * colour : 
 * pwm  :
 * mode : ref led_colour
 */
int led_mode_bright(struct leds_t *leds)
{
	int ret = 0;
	int pwm = sizeof(led_recoup)-1;
	if(!leds->board){
		sn3236_led_cal(pwm,leds);
	}else{
		sn3218_led_cal(pwm,leds);
	}
	ret = LEDDriver_Enable(leds);
	if(ret < 0){
		Debug("## i2cWrite fail\n");
		return -1;
	}
}


int led_mode_breath(struct leds_t *leds)
{
	unsigned char num = 0;
	int ret = 0;
	for(int num=0;num<sizeof(led_recoup);num++){
		if(!leds->breakin){
			if(!leds->board){
				sn3236_led_cal(num,leds);
			}else{
				sn3218_led_cal(num,leds);
			}
			ret = LEDDriver_Enable(leds);
			if(ret < 0){
				Debug("## i2cWrite fail\n");
				return -1;
			}
		}else{
			//printf("1 breking here %d\n",__LINE__);
			leds->breakin = 0;
			return 0;
		}
	}
	for(int num=sizeof(led_recoup)-1;num>=0;num--){
		if(!leds->breakin){
			if(!leds->board){
				sn3236_led_cal(num,leds);
			}else{
				sn3218_led_cal(num,leds);
			}
			ret = LEDDriver_Enable(leds);
			if(ret < 0){
				Debug("## i2cWrite fail\n");
				return -1;
			}
		}else{
			leds->breakin = 0;
			return 0;
		}
	}
	return 0;
}

int led_cyan_blue_blink(struct leds_t *leds)
{
	if(!leds->board){
		leds->colour = BLUE;
		leds->count  = CNT1;
		leds->effect = MODE3;
		led_mode_bright(leds);

		usleep(150*1000);//150ms
		leds->colour = BLUE;
		leds->count  = CNT1;
		leds->effect = MODE4;
		led_mode_bright(leds);

		usleep(150*1000);//150ms
	}else{
		leds->effect = MODE4;
		led_mode_bright(leds);
		usleep(150*1000);//150ms

		leds->effect = MODE1;
		led_mode_bright(leds);
		usleep(500*1000);//500ms
	}
}



int led_cyan_blue_breath(struct leds_t *leds)
{

	if(!leds->board){
		leds->colour = RED;
		leds->count  = CNT1;
		leds->effect = MODE5;
		led_mode_breath(leds);
		//ledShow(MODE_BREATH_RED_CYAN);
		usleep(500*1000);
		leds->colour = BLUE;
		leds->count  = CNT1;
		leds->effect = MODE1;
		led_mode_breath(leds);
		usleep(500*1000);
	}else{
		leds->effect = MODE4;
		led_mode_breath(leds);
		usleep(500*1000);

		leds->effect = MODE1;
		led_mode_breath(leds);
		usleep(500*1000);
	}
	return 0;
}

int led_cyan_blink(struct leds_t *leds)
{

	if(!leds->board){
		printf("sn3236 no effect\n");
	}else{
		leds->effect = MODE4;
		led_mode_bright(leds);
		usleep(150*1000);
		LEDDriver_GlobalOff(leds);
		usleep(150*1000);
	}
}



void *led_thread(void *arg)
{
	struct leds_t *leds = (struct leds_t *)arg;
	pthread_detach(pthread_self());
	while(1){
		//printf("leds->mode = %d board = %d\n",leds->mode,leds->board);
		switch(leds->mode){
			case MODE_THINKING:
				led_cyan_blue_blink(leds);
				break;
			case MODE_SPEAKING:
				led_cyan_blue_breath(leds);
				break;
			case MODE_RED:
				leds->colour = RED;
				leds->count  = CNT1;
				leds->effect = MODE1;
				led_mode_bright(leds);
				break;
			case MODE_GREEN:
				leds->colour = GREEN;
				leds->count  = CNT1;
				leds->effect = MODE1;
				led_mode_bright(leds);
				break;
			case MODE_BLUE:
				leds->colour = BLUE;
				leds->count  = CNT1;
				leds->effect = MODE1;
				led_mode_bright(leds);
				break;
			case MODE_LISTENING:
			case MODE_CYAN:
				if(!leds->board){
					leds->colour = RED;
					leds->count  = CNT1;
					leds->effect = MODE5;
					led_mode_bright(leds);
				}else{
					led_cyan_blink(leds);
				}
				break;
			case MODE_CYAN_BLUE:
				leds->colour = BLUE;
				leds->count  = CNT1;
				leds->effect = MODE3;
				led_mode_bright(leds);
				break;
			case MODE_BLUE_CYAN:
				leds->colour = BLUE;
				leds->count  = CNT1;
				leds->effect = MODE4;
				led_mode_bright(leds);
				break;
			case MODE_BREATH_R:
				leds->colour = RED;
				leds->count  = CNT1;
				leds->effect = MODE1;
				led_mode_breath(leds);
				break;
			case MODE_BREATH_G:
				leds->colour = GREEN;
				leds->count  = CNT1;
				leds->effect = MODE1;
				led_mode_breath(leds);
				break;
			case MODE_BREATH_B:
				leds->colour = BLUE;
				leds->count  = CNT1;
				leds->effect = MODE1;
				led_mode_breath(leds);
				break;
			case MODE_BREATH_RED_CYAN:
				leds->colour = RED;
				leds->count  = CNT1;
				leds->effect = MODE5;
				led_mode_breath(leds);
				break;
			case MODE_DEFAULT:
				LEDDriver_GlobalOff(leds);
				usleep(100*1000);
				break;
			default:
				//printf("mode defaulet\n");
				LEDDriver_GlobalOff(leds);
				usleep(100*1000);
				break;
		}
	}
}
void* ledSn32xxInit(int board)
{
	Debug("ledSn32xxInit  into here!\n");
	int ret = -1;
	struct leds_t* leds = malloc(sizeof(struct leds_t));
	memset(leds,0,sizeof(struct leds_t));
	leds->i2cNum = -1;
	leds->working = 1;
	leds->board = board;
	ret = i2cInit(&leds->i2cNum);
	if(ret < 0){
		Debug("i2cInit fail");
		return NULL;
	}
	LEDDriver_Init(leds);
	ret = pthread_create(&leds->thread,NULL,led_thread,leds);
	if(ret < 0){
		Debug("pthread_create fail");
		return NULL;
	}
	return (void *)leds;
}

int ledSn32xxShow(void* l,int mode){
	if( l == NULL ){
		printf("%s:void* l == NULL\n",__func__);
		return -1;
	}
	struct leds_t *leds = (struct leds_t *)l;
	Debug("ledShow mode = %d",mode);
	if(leds->working){
		leds->breakin = 1;
		leds->mode = mode;
		leds->def_flag = 0;
		return 0;
	}else{
		return -1;
	}
}

int ledSn32xxRelease(void* l)
{
	if( l == NULL ){
		printf("%s:void* l == NULL\n",__func__);
		return -1;
	}
	struct leds_t *leds = (struct leds_t *)l;
	Debug("#### ledRelease");
	i2cRelease(&leds->i2cNum);
	if(l) free(l);
	return 0;
}
