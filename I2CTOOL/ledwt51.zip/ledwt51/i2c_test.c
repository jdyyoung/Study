/*
 *
 */

#include "i2cWrite.h"
#include <unistd.h>

#define _I2C_DEVICE_ADDR 0x3c

int i2cNum=-1;

int main()
{
	unsigned char regValue[] = {0x3f};
	unsigned char reg[] = {0x13,0x14,0x15,0x01,0x16};
	unsigned char* data_buf;
	int ret = 0;
	ret = i2cInit(&i2cNum);
	if(ret < 0){
		printf("i2c init fail \n");
		return -1;
	}

	ret = i2cReadbyte(&i2cNum,_I2C_DEVICE_ADDR,reg[0],data_buf);
	if(ret < 0){
		printf("i2c write fail \n");
		return -1;
	}
	sleep(1);
	printf("[%d]:data_buf=0x%02x\n",*data_buf);

	ret = i2cWriteNbyte(&i2cNum,_I2C_DEVICE_ADDR,reg[0],1,&regValue[0]);
	if(ret < 0){
		printf("i2c write fail \n");
		return -1;
	}
	sleep(1);
	ret = i2cReadbyte(&i2cNum,_I2C_DEVICE_ADDR,reg[0],data_buf);
	if(ret < 0){
		printf("i2c write fail \n");
		return -1;
	}

	printf("[%d]:data_buf=0x%02x\n",*data_buf);
	ret = i2cRelease(&i2cNum);
	if(ret < 0){
		printf("i2c releasse fail \n");
		return -1;
	}
	return 0;
}




